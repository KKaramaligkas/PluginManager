UmdImageCreator 1.7 by sarami, https://github.com/saramibreak/UmdImageCreator
Licensed under the Apache License 2.0 (LICENSE.txt).

Built by FasterARK powerup from tag v1.7 (commit 85a6ad8) without changes to the
source, with -Dstrnicmp=strncasecmp for today's PSP toolchain.

Start it from the Game column with the UMD in the drive:
  Circle    dump the disc to ms0:/ISO/<disc ID>.iso, with logs
  Cross     write the logs only
  Triangle  quit
UMD Video discs go to ms0:/ISO/VIDEO/. The app loads ms0:/seplugins/pspumdman.prx.
